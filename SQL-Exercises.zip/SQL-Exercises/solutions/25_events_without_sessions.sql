-- ============================================================
-- Exercise 25: Events Without Sessions
-- List all events that currently have no sessions scheduled
-- under them.
-- ============================================================

SELECT
    e.event_id,
    e.title,
    e.city,
    e.status,
    e.start_date
FROM Events e
WHERE e.event_id NOT IN (
    SELECT DISTINCT event_id
    FROM Sessions
)
ORDER BY e.start_date;
