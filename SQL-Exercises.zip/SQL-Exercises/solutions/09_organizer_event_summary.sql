-- ============================================================
-- Exercise 9: Organizer Event Summary
-- For each event organizer, show the number of events created
-- and their current status (upcoming, completed, cancelled).
-- ============================================================

SELECT
    u.user_id,
    u.full_name                                                    AS organizer_name,
    COUNT(e.event_id)                                              AS total_events,
    COUNT(CASE WHEN e.status = 'upcoming'   THEN 1 END)           AS upcoming_count,
    COUNT(CASE WHEN e.status = 'completed'  THEN 1 END)           AS completed_count,
    COUNT(CASE WHEN e.status = 'cancelled'  THEN 1 END)           AS cancelled_count
FROM Users u
JOIN Events e ON u.user_id = e.organizer_id
GROUP BY u.user_id, u.full_name
ORDER BY total_events DESC;
