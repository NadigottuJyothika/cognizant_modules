-- ============================================================
-- Exercise 18: Resource Availability Check
-- List all events that do not have any resources uploaded.
-- ============================================================

SELECT
    e.event_id,
    e.title,
    e.city,
    e.status,
    e.start_date
FROM Events e
WHERE e.event_id NOT IN (
    SELECT DISTINCT event_id
    FROM Resources
)
ORDER BY e.start_date;
