-- ============================================================
-- Exercise 15: Event Session Time Conflict
-- Identify overlapping sessions within the same event
-- (sessions whose start and end times conflict).
-- Two sessions overlap when: A.start_time < B.end_time
--                        AND A.end_time   > B.start_time
-- ============================================================

SELECT
    a.event_id,
    a.session_id   AS session_a_id,
    a.title        AS session_a_title,
    a.start_time   AS a_start,
    a.end_time     AS a_end,
    b.session_id   AS session_b_id,
    b.title        AS session_b_title,
    b.start_time   AS b_start,
    b.end_time     AS b_end
FROM Sessions a
JOIN Sessions b
  ON  a.event_id   = b.event_id        -- same event
  AND a.session_id < b.session_id      -- avoid duplicate pairs
  AND a.start_time < b.end_time        -- overlap condition
  AND a.end_time   > b.start_time      -- overlap condition
ORDER BY a.event_id, a.session_id;
