# SQL Exercises - ANSI SQL Using MySQL

## Overview
This repository contains solutions to 25 SQL exercises based on an event management database schema. The exercises cover various SQL concepts including joins, subqueries, aggregations, date functions, and analytical queries.

## Database Schema
The database consists of 6 tables:
- **Users** - User information and profiles
- **Events** - Event details and scheduling
- **Sessions** - Event sessions with speakers
- **Registrations** - User event registrations
- **Feedback** - User ratings and comments
- **Resources** - Event resources (PDFs, images, links)

## File Structure
```
SQL-Exercises/
├── README.md               # Project documentation
├── schema.sql              # Database schema creation
├── sample_data.sql         # Sample data insertion
└── solutions/              # All exercise solutions
    ├── 01_user_upcoming_events.sql
    ├── 02_top_rated_events.sql
    ├── 03_inactive_users.sql
    ├── 04_peak_session_hours.sql
    ├── 05_most_active_cities.sql
    ├── 06_event_resource_summary.sql
    ├── 07_low_feedback_alerts.sql
    ├── 08_sessions_per_upcoming_event.sql
    ├── 09_organizer_event_summary.sql
    ├── 10_feedback_gap.sql
    ├── 11_daily_new_user_count.sql
    ├── 12_event_with_maximum_sessions.sql
    ├── 13_average_rating_per_city.sql
    ├── 14_most_registered_events.sql
    ├── 15_event_session_time_conflict.sql
    ├── 16_unregistered_active_users.sql
    ├── 17_multi_session_speakers.sql
    ├── 18_resource_availability_check.sql
    ├── 19_completed_events_feedback_summary.sql
    ├── 20_user_engagement_index.sql
    ├── 21_top_feedback_providers.sql
    ├── 22_duplicate_registrations_check.sql
    ├── 23_registration_trends.sql
    ├── 24_average_session_duration.sql
    └── 25_events_without_sessions.sql
```

## How to Run
1. Create a MySQL database:
   ```sql
   CREATE DATABASE event_management;
   USE event_management;
   ```
2. Run `schema.sql` to create tables
3. Run `sample_data.sql` to populate sample data
4. Execute any solution file from the `solutions/` folder

## Exercises Covered
| # | Title | Concepts |
|---|-------|----------|
| 01 | User Upcoming Events | JOIN, WHERE, ORDER BY |
| 02 | Top Rated Events | AVG, HAVING, GROUP BY |
| 03 | Inactive Users | NOT IN, Subquery, Date arithmetic |
| 04 | Peak Session Hours | HOUR(), COUNT, GROUP BY |
| 05 | Most Active Cities | COUNT DISTINCT, LIMIT |
| 06 | Event Resource Summary | CASE WHEN, LEFT JOIN |
| 07 | Low Feedback Alerts | JOIN, WHERE filter |
| 08 | Sessions per Upcoming Event | LEFT JOIN, COUNT |
| 09 | Organizer Event Summary | CASE WHEN, GROUP BY |
| 10 | Feedback Gap | NOT IN, Subquery |
| 11 | Daily New User Count | Date filter, GROUP BY |
| 12 | Event with Maximum Sessions | Nested subquery, MAX |
| 13 | Average Rating per City | AVG, GROUP BY |
| 14 | Most Registered Events | COUNT, ORDER BY, LIMIT |
| 15 | Event Session Time Conflict | Self JOIN, overlap logic |
| 16 | Unregistered Active Users | NOT IN, INTERVAL |
| 17 | Multi-Session Speakers | GROUP_CONCAT, HAVING |
| 18 | Resource Availability Check | NOT IN, Subquery |
| 19 | Completed Events Feedback Summary | LEFT JOIN, AVG, COUNT |
| 20 | User Engagement Index | COUNT DISTINCT, LEFT JOIN |
| 21 | Top Feedback Providers | COUNT, ORDER BY, LIMIT |
| 22 | Duplicate Registrations Check | HAVING COUNT > 1 |
| 23 | Registration Trends | DATE_FORMAT, GROUP BY |
| 24 | Average Session Duration | TIMESTAMPDIFF, AVG |
| 25 | Events Without Sessions | NOT IN, Subquery |

## Author
[Your Name]

## Date
June 2025
