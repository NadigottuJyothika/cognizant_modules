import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BasicJdbcExample {
    public static void main(String[] args) {
        // For SQLite:
        String dbUrl = "jdbc:sqlite:students.db";
        String username = "";
        String password = "";

        // For MySQL, uncomment and configure these values instead:
        // String dbUrl = "jdbc:mysql://localhost:3306/your_database?serverTimezone=UTC";
        // String username = "your_user";
        // String password = "your_password";

        String query = "SELECT id, name, grade FROM students";

        try {
            // Load driver class explicitly if needed.
            // For SQLite: org.sqlite.JDBC
            // For MySQL: com.mysql.cj.jdbc.Driver
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC driver not found: " + e.getMessage());
            return;
        }

        try (Connection connection = DriverManager.getConnection(dbUrl, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            System.out.println("Students table results:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String grade = resultSet.getString("grade");
                System.out.printf("ID=%d, Name=%s, Grade=%s%n", id, name, grade);
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}
