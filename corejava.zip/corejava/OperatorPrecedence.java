public class OperatorPrecedence {
    public static void main(String[] args) {
        int result1 = 10 + 5 * 2;
        int result2 = (10 + 5) * 2;
        int result3 = 20 / 5 + 3 * 2;
        int result4 = 20 / (5 + 3) * 2;

        System.out.println("Expression: 10 + 5 * 2");
        System.out.println("Result: " + result1);
        System.out.println("Explanation: Multiplication is evaluated before addition, so 5 * 2 = 10, then 10 + 10 = 20.\n");

        System.out.println("Expression: (10 + 5) * 2");
        System.out.println("Result: " + result2);
        System.out.println("Explanation: Parentheses change the order: 10 + 5 = 15, then 15 * 2 = 30.\n");

        System.out.println("Expression: 20 / 5 + 3 * 2");
        System.out.println("Result: " + result3);
        System.out.println("Explanation: Division and multiplication are evaluated before addition. 20 / 5 = 4 and 3 * 2 = 6, then 4 + 6 = 10.\n");

        System.out.println("Expression: 20 / (5 + 3) * 2");
        System.out.println("Result: " + result4);
        System.out.println("Explanation: Parentheses first: 5 + 3 = 8, then 20 / 8 = 2, then 2 * 2 = 4.");
    }
}
