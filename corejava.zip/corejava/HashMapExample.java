import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashMapExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<Integer, String> studentMap = new HashMap<>();

        System.out.print("How many student entries would you like to add? ");
        int count = scanner.nextInt();

        for (int i = 0; i < count; i++) {
            System.out.print("Enter student ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter student name: ");
            String name = scanner.nextLine();
            studentMap.put(id, name);
        }

        System.out.print("Enter an ID to look up: ");
        int lookupId = scanner.nextInt();

        String studentName = studentMap.get(lookupId);
        if (studentName != null) {
            System.out.println("Student name: " + studentName);
        } else {
            System.out.println("No student found with ID " + lookupId);
        }

        scanner.close();
    }
}
