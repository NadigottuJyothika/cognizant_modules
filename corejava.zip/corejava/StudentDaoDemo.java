public class StudentDaoDemo {
    public static void main(String[] args) {
        // SQLite example
        String dbUrl = "jdbc:sqlite:students.db";
        String username = "";
        String password = "";

        // MySQL example (uncomment and configure):
        // String dbUrl = "jdbc:mysql://localhost:3306/your_database?serverTimezone=UTC";
        // String username = "your_user";
        // String password = "your_password";

        StudentDAO studentDAO = new StudentDAO(dbUrl, username, password);

        Student student = new Student("Alice", "A");
        try {
            studentDAO.insertStudent(student);
            System.out.println("Inserted student: " + student);

            student.setName("Alice Johnson");
            student.setGrade("A+");
            boolean updated = studentDAO.updateStudent(student);
            System.out.println("Update successful: " + updated);
            System.out.println("Updated student: " + student);
        } catch (Exception e) {
            System.out.println("Database operation failed: " + e.getMessage());
        }
    }
}
