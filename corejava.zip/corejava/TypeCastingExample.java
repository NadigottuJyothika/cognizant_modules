public class TypeCastingExample {
    public static void main(String[] args) {
        double decimalValue = 12.75;
        int intValue = (int) decimalValue;
        System.out.println("Double value: " + decimalValue);
        System.out.println("After casting to int: " + intValue);

        int wholeNumber = 5;
        double doubleValue = (double) wholeNumber;
        System.out.println("Int value: " + wholeNumber);
        System.out.println("After casting to double: " + doubleValue);
    }
}
