import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class VirtualThreadsExample {
    public static void main(String[] args) {
        int count = 100_000;

        System.out.println("Launching " + count + " virtual threads...");
        Instant start = Instant.now();

        List<Thread> threads = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            Thread thread = Thread.startVirtualThread(() -> {
                // Minimal work to keep this example lightweight.
                System.out.print(".");
            });
            threads.add(thread);
        }

        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        Instant end = Instant.now();
        System.out.println("\nVirtual threads completed in " + Duration.between(start, end).toMillis() + " ms");
    }
}
