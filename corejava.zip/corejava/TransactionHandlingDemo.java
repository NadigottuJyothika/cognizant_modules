import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TransactionHandlingDemo {
    public static void main(String[] args) {
        // SQLite example
        String dbUrl = "jdbc:sqlite:accounts.db";
        String username = "";
        String password = "";

        // MySQL example (uncomment and configure):
        // String dbUrl = "jdbc:mysql://localhost:3306/your_database?serverTimezone=UTC";
        // String username = "your_user";
        // String password = "your_password";

        createAccountsTableIfNeeded(dbUrl);

        AccountTransactionDAO dao = new AccountTransactionDAO(dbUrl, username, password);

        try {
            System.out.println("Transferring 50.00 from account 1 to account 2...");
            dao.transfer(1, 2, 50.00);
            System.out.println("Transfer completed successfully.");
        } catch (SQLException ex) {
            System.out.println("Transfer failed: " + ex.getMessage());
        }
    }

    private static void createAccountsTableIfNeeded(String dbUrl) {
        String createTableSql = "CREATE TABLE IF NOT EXISTS accounts ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "balance REAL NOT NULL" 
                + ")";
        String insertSql1 = "INSERT INTO accounts (name, balance) SELECT 'Alice', 100.0 WHERE NOT EXISTS (SELECT 1 FROM accounts WHERE id = 1)";
        String insertSql2 = "INSERT INTO accounts (name, balance) SELECT 'Bob', 50.0 WHERE NOT EXISTS (SELECT 1 FROM accounts WHERE id = 2)";

        try (Connection connection = DriverManager.getConnection(dbUrl);
             Statement statement = connection.createStatement()) {
            statement.execute(createTableSql);
            statement.execute(insertSql1);
            statement.execute(insertSql2);
        } catch (SQLException e) {
            System.out.println("Error setting up accounts table: " + e.getMessage());
        }
    }
}
