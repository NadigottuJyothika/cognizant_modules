import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {
    public static void main(String[] args) {
        int port = 12345;
        System.out.println("Starting chat server on port " + port + "...");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Waiting for client connection...");
            try (Socket clientSocket = serverSocket.accept();
                 BufferedReader clientReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter clientWriter = new PrintWriter(clientSocket.getOutputStream(), true);
                 BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))) {

                System.out.println("Client connected: " + clientSocket.getRemoteSocketAddress());

                Thread receiveThread = new Thread(() -> {
                    try {
                        String message;
                        while ((message = clientReader.readLine()) != null) {
                            System.out.println("Client: " + message);
                        }
                    } catch (IOException e) {
                        System.out.println("Connection closed by client.");
                    }
                });
                receiveThread.start();

                String line;
                while ((line = consoleReader.readLine()) != null) {
                    clientWriter.println(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}
