import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountTransactionDAO {
    private final String dbUrl;
    private final String username;
    private final String password;

    public AccountTransactionDAO(String dbUrl, String username, String password) {
        this.dbUrl = dbUrl;
        this.username = username;
        this.password = password;
    }

    public void transfer(int fromAccountId, int toAccountId, double amount) throws SQLException {
        String selectBalanceSql = "SELECT balance FROM accounts WHERE id = ?";
        String debitSql = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
        String creditSql = "UPDATE accounts SET balance = balance + ? WHERE id = ?";

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement selectStmt = connection.prepareStatement(selectBalanceSql);
                 PreparedStatement debitStmt = connection.prepareStatement(debitSql);
                 PreparedStatement creditStmt = connection.prepareStatement(creditSql)) {

                selectStmt.setInt(1, fromAccountId);
                try (ResultSet rs = selectStmt.executeQuery()) {
                    if (!rs.next()) {
                        throw new SQLException("Source account not found: " + fromAccountId);
                    }
                    double fromBalance = rs.getDouble("balance");
                    if (fromBalance < amount) {
                        throw new SQLException("Insufficient funds in account " + fromAccountId);
                    }
                }

                debitStmt.setDouble(1, amount);
                debitStmt.setInt(2, fromAccountId);
                int debitRows = debitStmt.executeUpdate();
                if (debitRows != 1) {
                    throw new SQLException("Failed to debit account " + fromAccountId);
                }

                creditStmt.setDouble(1, amount);
                creditStmt.setInt(2, toAccountId);
                int creditRows = creditStmt.executeUpdate();
                if (creditRows != 1) {
                    throw new SQLException("Failed to credit account " + toAccountId);
                }

                connection.commit();
            } catch (SQLException ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, username, password);
    }
}
