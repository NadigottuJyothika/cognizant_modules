public class ThreadExample {
    public static void main(String[] args) {
        Thread thread1 = new MessageThread("Thread-1", 5);
        Thread thread2 = new Thread(new MessageRunnable("Thread-2", 5));

        thread1.start();
        thread2.start();
    }
}

class MessageThread extends Thread {
    private final String name;
    private final int count;

    public MessageThread(String name, int count) {
        this.name = name;
        this.count = count;
    }

    @Override
    public void run() {
        for (int i = 1; i <= count; i++) {
            System.out.println(name + " message " + i);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

class MessageRunnable implements Runnable {
    private final String name;
    private final int count;

    public MessageRunnable(String name, int count) {
        this.name = name;
        this.count = count;
    }

    @Override
    public void run() {
        for (int i = 1; i <= count; i++) {
            System.out.println(name + " message " + i);
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
