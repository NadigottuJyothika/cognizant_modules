package com.utils;

public class StringUtils {
    public static String formatGreeting(String name) {
        if (name == null || name.isBlank()) {
            return "Hello, Guest!";
        }
        return "Hello, " + name.trim() + "!";
    }
}
