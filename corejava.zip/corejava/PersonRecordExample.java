import java.util.List;
import java.util.stream.Collectors;

public class PersonRecordExample {
    public static void main(String[] args) {
        Person person1 = new Person("Alice", 25);
        Person person2 = new Person("Bob", 17);
        Person person3 = new Person("Charlie", 30);

        System.out.println(person1);
        System.out.println(person2);
        System.out.println(person3);

        List<Person> people = List.of(person1, person2, person3);

        List<Person> adults = people.stream()
                .filter(person -> person.age() >= 18)
                .collect(Collectors.toList());

        System.out.println("\nAdults:");
        adults.forEach(System.out::println);
    }
}

record Person(String name, int age) {}
